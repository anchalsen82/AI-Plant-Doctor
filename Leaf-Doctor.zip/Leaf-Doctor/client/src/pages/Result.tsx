import { useRoute, Link } from "wouter";
import { useScan } from "@/hooks/use-scans";
import { PageTransition } from "@/components/PageTransition";
import { Loader2, ArrowLeft, ShieldAlert, HeartPulse, ShoppingBag, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Result() {
  const [, params] = useRoute("/result/:id");
  const id = parseInt(params?.id || "0");
  const { data: scan, isLoading, isError } = useScan(id);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <p className="text-muted-foreground animate-pulse">Retrieving diagnosis...</p>
      </div>
    );
  }

  if (isError || !scan) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <ShieldAlert className="w-16 h-16 text-destructive/50" />
        <h2 className="text-2xl font-bold">Scan Not Found</h2>
        <Link href="/scan">
          <button className="btn-primary">Start New Scan</button>
        </Link>
      </div>
    );
  }

  // Determine severity color based on confidence or just default to warning
  const isHighConfidence = parseInt(scan.confidence || "0") > 80;

  return (
    <PageTransition>
      <div className="space-y-8">
        <div className="flex items-center gap-4">
          <Link href="/scan">
            <button className="p-2 hover:bg-emerald-50 rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6 text-emerald-800" />
            </button>
          </Link>
          <h1 className="text-3xl font-bold">Analysis Results</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left Column - Image & Quick Status */}
          <div className="space-y-6">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-emerald-900/10 border-4 border-white">
              <img 
                src={scan.imageUrl} 
                alt="Analyzed Plant" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-white/20">
                <span className="text-sm font-bold text-emerald-800">
                  {new Date(scan.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>

            <div className={cn(
              "p-6 rounded-2xl border flex items-center gap-4 shadow-lg",
              isHighConfidence 
                ? "bg-emerald-50 border-emerald-200 text-emerald-900" 
                : "bg-amber-50 border-amber-200 text-amber-900"
            )}>
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center shrink-0",
                isHighConfidence ? "bg-emerald-200" : "bg-amber-200"
              )}>
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm opacity-80 font-medium uppercase tracking-wider">Detection Confidence</p>
                <p className="text-2xl font-bold">{scan.confidence || "Unknown"}%</p>
              </div>
            </div>
          </div>

          {/* Right Column - Diagnosis & Treatment */}
          <div className="space-y-8">
            <div className="space-y-2">
              <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Detected Disease</p>
              <h2 className="text-4xl md:text-5xl font-bold text-emerald-950 leading-tight">
                {scan.disease || "Unknown Issue"}
              </h2>
            </div>

            <div className="glass-card p-8 space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shrink-0 mt-1">
                  <HeartPulse className="w-5 h-5" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Treatment Plan</h3>
                  <div className="prose prose-sm prose-emerald text-muted-foreground">
                    <p>{scan.treatment || "No specific treatment recommended yet."}</p>
                  </div>
                </div>
              </div>

              <div className="w-full h-px bg-border/50" />

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 shrink-0 mt-1">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Prevention Tips</h3>
                  <div className="prose prose-sm prose-emerald text-muted-foreground">
                    <p>{scan.prevention || "Keep plant in optimal conditions."}</p>
                  </div>
                </div>
              </div>

              <div className="w-full h-px bg-border/50" />

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 shrink-0 mt-1">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div className="space-y-4 w-full">
                  <h3 className="text-xl font-bold">Recommended Medicine</h3>
                  <div className="bg-orange-50 rounded-xl p-4 border border-orange-100">
                    <p className="font-medium text-orange-900 mb-3">
                      {scan.medicine || "General plant fungicide"}
                    </p>
                    <a 
                      href={`https://www.amazon.com/s?k=${encodeURIComponent(scan.medicine || "plant medicine")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm font-bold text-orange-700 hover:text-orange-800 hover:underline"
                    >
                      Buy on Amazon <ArrowRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
