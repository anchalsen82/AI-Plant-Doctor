import { Link } from "wouter";
import { AlertCircle } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";

export default function NotFound() {
  return (
    <PageTransition>
      <div className="min-h-[80vh] flex flex-col items-center justify-center text-center space-y-6">
        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center text-red-400 animate-bounce">
          <AlertCircle className="w-12 h-12" />
        </div>
        
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-slate-900">Page Not Found</h1>
          <p className="text-slate-500 max-w-sm mx-auto">
            The page you are looking for might have been removed or is temporarily unavailable.
          </p>
        </div>

        <Link href="/">
          <button className="btn-primary">Return Home</button>
        </Link>
      </div>
    </PageTransition>
  );
}
