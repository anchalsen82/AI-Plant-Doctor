import { Link } from "wouter";
import { useScans } from "@/hooks/use-scans";
import { PageTransition } from "@/components/PageTransition";
import { Loader2, Calendar, ArrowRight, ImageOff } from "lucide-react";
import { format } from "date-fns";

export default function History() {
  const { data: scans, isLoading } = useScans();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold">Scan History</h1>
            <p className="text-muted-foreground">Your past diagnoses and records</p>
          </div>
          <Link href="/scan">
            <button className="btn-primary text-sm px-4 py-2">
              New Diagnosis
            </button>
          </Link>
        </div>

        {!scans || scans.length === 0 ? (
          <div className="glass-card p-12 text-center flex flex-col items-center justify-center space-y-4 min-h-[400px]">
            <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-300 mb-4">
              <ImageOff className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-emerald-950">No scans yet</h3>
            <p className="text-muted-foreground max-w-sm">
              Start by uploading a photo of a plant leaf to get your first diagnosis.
            </p>
            <Link href="/scan">
              <button className="btn-secondary mt-4">Start First Scan</button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {scans.map((scan) => (
              <Link key={scan.id} href={`/result/${scan.id}`}>
                <div className="group glass-card overflow-hidden hover:shadow-2xl hover:border-emerald-200 transition-all duration-300 cursor-pointer h-full flex flex-col">
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img 
                      src={scan.imageUrl} 
                      alt={scan.disease || "Scan"} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-medium border border-white/20">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(scan.createdAt), 'MMM d, yyyy')}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-lg font-bold text-emerald-950 mb-2 line-clamp-1 group-hover:text-primary transition-colors">
                      {scan.disease || "Unknown Condition"}
                    </h3>
                    <div className="mt-auto flex items-center justify-between pt-4 border-t border-emerald-50">
                      <span className="text-sm font-medium text-emerald-600/80">
                        {scan.confidence ? `${scan.confidence}% Confidence` : 'Pending Analysis'}
                      </span>
                      <ArrowRight className="w-5 h-5 text-emerald-300 group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  );
}
