import { Link } from "wouter";
import { ArrowRight, ShieldCheck, Activity, UploadCloud } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <PageTransition>
      <div className="flex flex-col items-center justify-center min-h-[80vh] text-center space-y-12">
        <div className="space-y-6 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100/50 text-emerald-800 border border-emerald-200 text-sm font-medium animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            AI-Powered Plant Diagnosis
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-emerald-950 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
            Heal your plants with <span className="text-primary italic">intelligence</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            Instantly identify plant diseases, get expert treatment plans, and find the right medicine. Just snap a photo.
          </p>

          <div className="pt-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300">
            <Link href="/scan">
              <button className="btn-primary flex items-center gap-3 text-lg group mx-auto">
                Scan Your Plant
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 w-full max-w-5xl mt-16 animate-in fade-in zoom-in-95 duration-1000 delay-500">
          <FeatureCard 
            icon={UploadCloud}
            title="Instant Upload"
            description="Take a photo or upload an image of your affected plant leaf."
          />
          <FeatureCard 
            icon={Activity}
            title="AI Diagnosis"
            description="Our advanced model identifies diseases with high accuracy."
          />
          <FeatureCard 
            icon={ShieldCheck}
            title="Expert Care"
            description="Get detailed treatment plans and prevention tips instantly."
          />
        </div>

        {/* Hero Image Section */}
        <div className="w-full max-w-5xl mx-auto mt-16 relative group animate-in fade-in zoom-in-95 duration-1000 delay-700">
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-10" />
          {/* Unsplash image of healthy green plants */}
          <img 
            src="https://pixabay.com/get/g2fafc60709bbfd9b5f4c6d170397487c8a2d93fb9a810355f0b92a0fc43fa981bbed89e467df9830f882b6ec481f57e4ad3843fd12e5c87d9c98c31d2bc24650_1280.jpg" 
            alt="Healthy lush plants" 
            className="w-full h-64 md:h-96 object-cover rounded-3xl shadow-2xl shadow-emerald-900/20 group-hover:scale-[1.02] transition-transform duration-700"
          />
        </div>
      </div>
    </PageTransition>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg shadow-emerald-900/5 border border-emerald-50 hover:border-emerald-200 transition-colors">
      <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 mb-4 mx-auto md:mx-0">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-xl font-bold mb-2 text-emerald-950">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}
