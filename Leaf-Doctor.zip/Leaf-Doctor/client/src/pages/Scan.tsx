import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Upload, X, Loader2, Image as ImageIcon } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { useAnalyzeScan } from "@/hooks/use-scans";
import { cn } from "@/lib/utils";

export default function Scan() {
  const [, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { mutate: analyze, isPending } = useAnalyzeScan();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = () => {
    if (selectedFile) {
      analyze(selectedFile, {
        onSuccess: (data) => {
          setLocation(`/result/${data.id}`);
        },
      });
    }
  };

  const clearSelection = () => {
    setPreview(null);
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  return (
    <PageTransition>
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold">Diagnose Your Plant</h1>
          <p className="text-muted-foreground">Upload a clear photo of the affected leaf or area.</p>
        </div>

        <div className="glass-card p-8 md:p-12">
          {!preview ? (
            <div
              className="border-2 border-dashed border-emerald-200 rounded-2xl p-12 text-center hover:bg-emerald-50/50 transition-colors cursor-pointer"
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Upload className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-emerald-900 mb-2">Click to Upload</h3>
              <p className="text-muted-foreground mb-4">or drag and drop your image here</p>
              <p className="text-xs text-emerald-600/60 uppercase tracking-widest font-semibold">Supports JPG, PNG, WEBP</p>
            </div>
          ) : (
            <div className="relative group">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-black/5 shadow-inner">
                <img src={preview} alt="Preview" className="w-full h-full object-contain" />
              </div>
              <button
                onClick={clearSelection}
                className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-red-500 transition-colors opacity-0 group-hover:opacity-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          )}

          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/*"
            onChange={handleFileSelect}
          />

          <div className="mt-8 flex justify-center">
            <button
              onClick={handleAnalyze}
              disabled={!selectedFile || isPending}
              className={cn(
                "btn-primary w-full md:w-auto min-w-[200px] flex items-center justify-center gap-2",
                isPending && "opacity-80 cursor-not-allowed"
              )}
            >
              {isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Activity className="w-5 h-5" />
                  Analyze Plant
                </>
              )}
            </button>
          </div>
        </div>

        <div className="bg-emerald-50/50 rounded-xl p-6 border border-emerald-100">
          <h4 className="font-semibold text-emerald-900 mb-3 flex items-center gap-2">
            <ImageIcon className="w-4 h-4" />
            Tips for best results
          </h4>
          <ul className="text-sm text-emerald-800/80 space-y-2 list-disc list-inside">
            <li>Make sure the affected area is in focus</li>
            <li>Take photos in good lighting conditions</li>
            <li>Try to capture the entire leaf if possible</li>
          </ul>
        </div>
      </div>
    </PageTransition>
  );
}
