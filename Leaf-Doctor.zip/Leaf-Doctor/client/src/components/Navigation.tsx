import { Link, useLocation } from "wouter";
import { Leaf, History, Upload, Activity } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: Leaf },
    { href: "/scan", label: "New Scan", icon: Upload },
    { href: "/history", label: "History", icon: History },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 md:top-0 md:bottom-auto z-50 bg-white/80 backdrop-blur-lg border-t md:border-t-0 md:border-b border-emerald-100 shadow-lg shadow-emerald-900/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="hidden md:flex items-center gap-2 group">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
              <Leaf className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-800 to-emerald-600">
              PlantDoctor
            </span>
          </Link>

          <div className="flex items-center justify-around w-full md:w-auto md:gap-8">
            {navItems.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex flex-col md:flex-row items-center gap-1 md:gap-2 px-4 py-2 rounded-xl transition-all duration-200",
                    isActive
                      ? "text-primary bg-emerald-50 font-semibold"
                      : "text-muted-foreground hover:text-emerald-700 hover:bg-emerald-50/50"
                  )}
                >
                  <Icon className={cn("w-6 h-6 md:w-5 md:h-5", isActive && "fill-current/20")} />
                  <span className="text-xs md:text-sm">{item.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
