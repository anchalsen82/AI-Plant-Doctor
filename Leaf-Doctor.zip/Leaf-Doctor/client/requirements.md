## Packages
framer-motion | Animations for page transitions and card interactions
lucide-react | Icons for the UI (already in base, but emphasizing use)

## Notes
- Theme: Nature/Green aesthetic
- Font: 'Outfit' for headers, 'DM Sans' for body
- Image Upload: Uses FormData for POST /api/scans/analyze
